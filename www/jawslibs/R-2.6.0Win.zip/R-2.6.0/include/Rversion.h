/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 132608
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "2"
#define R_MINOR  "6.0"
#define R_STATUS ""
#define R_YEAR   "2007"
#define R_MONTH  "10"
#define R_DAY    "03"
#define R_SVN_REVISION "43063"
#define R_FILEVERSION    2,60,43063,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
